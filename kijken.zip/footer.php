<footer>
    <img class="" src="" alt="">
    <article class="">
      </article>
    <article class="">
      </article>
</footer>
</html>