<?php require_once 'header.php'; ?>
<body>
    <main>
     <section>
         <video class="skycolor" autoplay loop muted src = "video/Skycolor.mp4"></video>
        <article>
          <h1 class="welkom">Menu</h1>
       </article>

        <article class="Block">
          <P id="Head">Welcome bij PixelGame</p>
          <p id="info">Zin in een potje gamen? Bij PixelGame zit je goed! Ontdek een wereld vol toffe, 
                       gratis spelletjes die je direct in je browser kunt spelen. Of je nu houdt van actie, puzzels, races of klassiekers,
                       wij hebben het allemaal. Geen installatie, geen wachttijd… gewoon klikken en spelen!</p>
        </article>
            <article class="Scoreboard">
           <p id="score">Highscore:</p>
        </article>
     </section>
</main>
</body>
<?php require_once 'footer.php'; ?>