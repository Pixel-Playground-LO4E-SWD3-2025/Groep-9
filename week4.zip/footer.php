<footer>
    <img class="footer-logo" src="img/panther.png" alt="Logo">
    <article>
       <p id="Watermark">&copy;2025 PixelGame David Orozco</p>
      </article>
</footer>
</html>