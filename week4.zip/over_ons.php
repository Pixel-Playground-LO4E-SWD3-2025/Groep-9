<?php require_once 'header.php'; ?>
<body>
    <main>
     <section>
         <video class="skycolor" autoplay loop muted src = "video/Skycolor.mp4"></video>
        <article>
          <h1 class="welkom">Over ons</h1>
       </article>

        <article class="Block">
          <P id="Head">over ons</p>
          <p id="info">Welkom bij PixelPlayground jouw online plek voor gratis spelletjes! Of je nu houdt van actie, puzzels of klassiekers, bij ons vind je altijd iets leuks om te spelen. Speel direct op je mobiel, tablet of computer, zonder downloads. Nieuwe games worden regelmatig toegevoegd!</p>
     </section>
</main>
</body>
<?php require_once 'footer.php'; ?>